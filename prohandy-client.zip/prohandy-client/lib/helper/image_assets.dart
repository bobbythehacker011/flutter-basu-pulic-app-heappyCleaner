class ImageAssets {
  static const avatar = "avatar";
  static const loadingImage = "loading_image";
  static const splash = "splash";
  static const homeHeaderShade = "home_header_shade";
  static const finding = "finding";
  static const verification = "verification";
  static const cancel = "cancel";
  static const image = "image";
  static const mapDark = "map_dark";
  static const mapLight = "map_light";
  static const emptyList = "empty_list";
  static const emptyConversation = "empty_conversation";
}
