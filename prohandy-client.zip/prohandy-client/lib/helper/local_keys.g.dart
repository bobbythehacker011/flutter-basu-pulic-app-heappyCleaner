import 'package:prohandy_client/helper/extension/string_extension.dart';

abstract class LocalKeys {
  static const String _state = "State";
  static const String _area = "Area";
  static const String _city = "City";
  static const String _selectAState = "Select a state";
  static const String _searchArea = "Search area";
  static const String _noResultFound = "No results found";
  static const String _selectArea = "Select area";
  static const String _selectFile = "Select File";
  static const String _fileRemoved = "File removed";
  static const String _fileSelected = "File selected";
  static const String _fileSelectFailed = "Failed to select the file.";
  static const String _noSelectedFile = "No file selected";
  static const String _clearFile = "Remove file";
  static const String _oops = "Oops";
  static const String _noConnectionFound = "No connection found";
  static const String _retry = "Retry";
  static const String _pullUp = "Pull up to load more";
  static const String _translatingText = "Translating text";
  static const String _cancel = "Cancel";
  static const String _okay = "Okay!";
  static const String _orderId = "Order Id";
  static const String _invalidUrl = "Invalid Url";
  static const String _requestTimeOut = "Request time out.";
  static const String _searchState = "Search state";
  static const String _selectState = "Select state";
  static const String _passLeastCharWarning =
      "Password should be at least 8 characters long";
  static const String _passUpperCaseWarning =
      "Password should contain at least 1 uppercase letter";
  static const String _passLowerCaseWarning =
      "Password should contain at least 1 lowercase letter";
  static const String _passDigitWarning =
      "Password should contain at least 1 digit";
  static const String _passCharacterWarning =
      "Password should contain at least 1 special character";
  static const String _selectDate = "Select Date";
  static const String _byCreatingAnAccountYouAgreeToThe =
      "By creating an account you agree to the";
  static const String _termsAndConditions = "Terms and Conditions";
  static const String _and = "and";
  static const String _privacyPolicy = "Privacy Policy";
  static const String _skip = "Skip";
  static const String _continue = "Continue";
  static const String _pressAgainToExit = "Press again to exit.";
  static const String _home = "Home";
  static const String _orders = "Orders";
  static const String _message = "Message";
  static const String _jobs = "Jobs";
  static const String _profile = "Profile";
  static const String _category = "Category";
  static const String _sliders = "Sliders";
  static const String _postAJob = "Post A Job";
  static const String _didNotFindWhatLookingFor =
      "Didn't find what you were looking for?";
  static const String _iamLookingFor = "I'm looking for";
  static const String _service = "Service";
  static const String _handyman = "Handyman";
  static const String _rating = "Rating";
  static const String _priceRange = "Price Range";
  static const String _imLookingServiceIn = "I'm looking service in";
  static const String _selectCity = "Select city";
  static const String _searchCity = "Search city";
  static const String _serviceUnits = "Service units";
  static const String _resetFilter = "Reset Filter";
  static const String _applyFilter = "Apply Filter";
  static const String _results = "Results";
  static const String _all = "All";
  static const String _booking = "Booking";
  static const String _payment = "Payment";
  static const String _pending = "Pending";
  static const String _accepted = "Accepted";
  static const String _inProgress = "In-Progress";
  static const String _complete = "Complete";
  static const String _canceled = "Canceled";
  static const String _orderList = "Order List";
  static const String _messages = "Messages";
  static const String _file = "File";
  static const String _allJobs = "All Jobs";
  static const String _budget = "Budget";
  static const String _applied = "Applied";
  static const String _jobDetails = "Job Details";
  static const String _when = "When?";
  static const String _where = "Where?";
  static const String _showMore = "Show more";
  static const String _showLess = "Show less";
  static const String _applicants = "Applicants";
  static const String _shortlisted = "Shortlisted";
  static const String _hired = "Hired";
  static const String _rejected = "Rejected";
  static const String _allOffers = "All applications";
  static const String _match = "Match";
  static const String _completionRate = "Completion Rate";
  static const String _applicationDetails = "Offer Details";
  static const String _jobCompleted = "Job Completed";
  static const String _memberSince = "Member Since";
  static const String _address = "Address";
  static const String _verificationStatus = "Verification Status";
  static const String _verified = "Verified";
  static const String _notVerified = "Not Verified";
  static const String _coverLetter = "Cover Letter";
  static const String _reject = "Reject";
  static const String _hireNow = "Hire Now";
  static const String _summary = "Summary";
  static const String _phone = "Phone";
  static const String _offered = "Offered";
  static const String _subtotal = "Subtotal";
  static const String _discount = "Discount";
  static const String _vat = "Tax";
  static const String _total = "Total";
  static const String _jobBasicInfoSuggestion =
      "Enter a title & choose job category you need";
  static const String _jobTitle = "Job Title";
  static const String _enterJobTitle = "Enter job title";
  static const String _selectCategory = "Select category";
  static const String _searchCategory = "Search category";
  static const String _whereDoYouNeedThis = "Where do you need this";
  static const String _where0 = "Where";
  static const String _dateSelected = "Date selected";
  static const String _dateSelectFailed = "Failed to select the date";
  static const String _selectTime = "Select Time";
  static const String _timeSelected = "Time selected";
  static const String _failedToSelectTime = "Failed to select the time";
  static const String _noTimeSelected = "No time selected";
  static const String _time = "Time";
  static const String _date = "Date";
  static const String _jobDescription = "Job Description";
  static const String _jobDescriptionSectionSuggestion = "Write about your job";
  static const String _enterYourBudget = "Enter your budget";
  static const String _description = "Description";
  static const String _enterDescription = "Enter description";
  static const String _addPhoto = "Add Photo";
  static const String _view = "View";
  static const String _remove = "Remove";
  static const String _uploadGalleryPhotos = "Upload Photos";
  static const String _uploadPhotosSuggestion =
      "Upload relevant photos to help understand what you need";
  static const String _back = "Back";
  static const String _edit = "Edit";
  static const String _postJob = "Post Job";
  static const String _areYouSure = "Are you sure?";
  static const String _congrats = "Congrats!";
  static const String _jobPostingSuccessDescription =
      "Your job has been posted. You will get application's after it gets approved by an admin";
  static const String _serviceDate = "Service Date";
  static const String _serviceAddress = "Service Address";
  static const String _signedInSuccessfully = "Signed in successfully";
  static const String _emailUsernameValidateText =
      "Enter your email or username";
  static const String _favoriteServices = "Favorite Services";
  static const String _pendingOrders = "Pending orders";
  static const String _completedOrders = "Completed orders";
  static const String _totalOrders = "Total orders";
  static const String _ratingAndReviews = "Rating & Reviews";
  static const String _supportTicket = "Support Ticket";
  static const String _notifications = "Notifications";
  static const String _addresses = "Addresses";
  static const String _paymentMethods = "Payment Methods";
  static const String _languages = "Languages";
  static const String _deleteAccount = "Delete Account";
  static const String _signOut = "Sign Out";
  static const String _personalInformation = "Personal Information";
  static const String _changeImage = "Change Image";
  static const String _editInformation = "Edit Information";
  static const String _changeEmail = "Change Email";
  static const String _changePhone = "Change Phone";
  static const String _changePassword = "Change Password";
  static const String _firstName = "First Name";
  static const String _enterFirstName = "Enter your first name";
  static const String _lastName = "Last Name";
  static const String _enterLastName = "Enter your last name";
  static const String _saveChanges = "Save Changes";
  static const String _verificationCodeWillBeSentToTheNewEmail =
      "A verification will be sent to your new email.";
  static const String _email = "Email";
  static const String _enterNewEmail = "Enter new email";
  static const String _sendVerificationCode = "Send Verification Code";
  static const String _sendingOtpToMail = "Sending OTP to email";
  static const String _resetPassword = "Reset password";
  static const String _passwordResetSuccessful = "Password reset successfully";
  static const String _verificationCode = "Verification code";
  static const String _enterYourVerificationCode =
      "Enter the verification that was sent to the email.";
  static const String _doNotShareCode =
      "Do not share your verification code with anyone.";
  static const String _didNotReceived = "Didn't received any code?";
  static const String _resend = "Resend again in";
  static const String _sendAgain = "Send Again";
  static const String _wrongOTPCode = "Wrong OTP Code";
  static const String _resendCode = "Resend Code";
  static const String _enterEmail = "Enter Email";
  static const String _verificationCodeWillBeSentToTheNewPhone =
      "A verification will be sent to your new phone";
  static const String _enterPhone = "Enter phone";
  static const String _enterYourPhoneVerificationCode =
      "Enter the verification that was sent to the phone";
  static const String _currentPassword = "Current Password";
  static const String _enterYourCurrentPassword = "Enter your current password";
  static const String _newPassword = "New Password";
  static const String _enterNewPassword = "Enter new password";
  static const String _reEnterNewPassword = "Re-enter new password";
  static const String _confirmPassword = "Confirm Password";
  static const String _passwordDidNotMatch = "Password didn't match";
  static const String _delete = "Delete";
  static const String _newTicket = "New Ticket";
  static const String _active = "Active";
  static const String _closed = "Closed";
  static const String _createTicket = "Create Ticket";
  static const String _title = "Title";
  static const String _enterTitle = "Enter title";
  static const String _department = "Department";
  static const String _selectDepartment = "Select department";
  static const String _selectPriority = "Select priority";
  static const String _priority = "Priority";
  static const String _newAddress = "New Address";
  static const String _addAddress = "Add Address";
  static const String _enterZipCode = "Enter zip code";
  static const String _zipCode = "Zip code";
  static const String _emergencyPhoneNumber = "Emergency phone number";
  static const String _office = "Office";
  static const String _overview = "Overview";
  static const String _reviews = "Reviews";
  static const String _faq = "FAQ";
  static const String _ourOffers = "Our Offers";
  static const String _whatIsNotIncluded = "What’s not included:";
  static const String _safetyAndSecurity = "Safety and Security";
  static const String _cancellationPolicy = "Cancellation Policy";
  static const String _bookService = "Book Service";
  static const String _serviceAddonsAndDate = "Service Addons and Date";
  static const String _addons = "Addons";
  static const String _dateAndSchedule = "Date and Schedule";
  static const String _selectDateAndSchedule = "Select date and schedule";
  static const String _availableSlots = "Available slots";
  static const String _bookingNoteExmp = "e.g. bring all equipment...";
  static const String _addNote = "Add Note";
  static const String _select = "Select";
  static const String _choseStaff = "Choose Staff";
  static const String _package = "Package";
  static const String _addToCart = "Add to Cart";
  static const String _proceedToPay = "Proceed to Pay";
  static const String _cart = "Cart";
  static const String _connectionTimeout = "Connection timeout";
  static const String _errorOccurred = "Error occurred";
  static const String _yourPaymentWillTerminate =
      "Your payment will be terminated.";
  static const String _yes = "Yes";
  static const String _invalidDeveloperKeys = "Invalid developer keys";
  static const String _loadingFailed = "Loading failed";
  static const String _paymentGateway = "Payment Gateways";
  static const String _username = "Username";
  static const String _enterUsername = "Enter username";
  static const String _cardNumber = "Card Number";
  static const String _invalidCardNumber = "Invalid card number";
  static const String _cvvCvc = "CVV/CVC";
  static const String _expireDate = "Expire Date";
  static const String _orderSummery = "Order Summery";
  static const String _shareDetails = "Share Details";
  static const String _bookingSuccessful = "Booking successful";
  static const String _billed = "Billed:";
  static const String _paymentStatus = "Payment Status";
  static const String _orderStatus = "Order Status";
  static const String _orderDetails = "Order Details";
  static const String _requestToCancel = "Request to Cancel";
  static const String _downloadInvoice = "Download Invoice";
  static const String _requestToCancelDesc =
      "Your cancellation request will be reviewed by the service provider. If approved, you will receive a refund minus a 15% cancellation fee.";
  static const String _id = "ID";
  static const String _schedule = "Schedule";
  static const String _sendMessage = "Send message";
  static const String _pleaseWriteMessageOrSelectAFile =
      "Please write message or select a file to send.";
  static const String _pullDown = "Pull down";
  static const String _noMessageFound = "No message found";
  static const String _signIn = "Sign In";
  static const String _password = "Password";
  static const String _enterPassword = "Enter password";
  static const String _forgotPassword = "Forgot password";
  static const String _rememberMe = "Remember Me";
  static const String _doNotHaveAccount = "Don't have an account?";
  static const String _signUp = "Sign up";
  static const String _otpSignIn = "Sign In with OTP";
  static const String _signInFailed = "Sign In Failed";
  static const String _signInWithGoogle = "Sign in with Google";
  static const String _signInWithFacebook = "Sign in with Facebook";
  static const String _signInWithApple = "Sign in with Apple";
  static const String _or = "Or";
  static const String _byProceedingIAgreeToThe =
      "By proceeding I agree to the ";
  static const String _haveAccount = "Already have an account?";
  static const String _signUpWithGoogle = "Sign up with Google";
  static const String _signUpWithFacebook = "Sign up with Facebook";
  static const String _signUpWithApple = "Sign up With Apple";
  static const String _retypePassword = "Retype password";
  static const String _verifyEmail = "Verify Email";
  static const String _uploadYourProfilePhoto =
      "Upload your profile photo to finish signing up";
  static const String _uploadProfilePhoto = "Upload Profile Photo";
  static const String _skipForLater = "Skip for Later";
  static const String _clickToSelectPhoto = "Click to Select Photo";
  static const String _youHaveSignedUpSuccessfully =
      "You have signed up successfully. Start hiring experts";
  static const String _enterValidEmailAddress = "Enter valid email address";
  static const String _enterTheOTP = "Enter the OTP";
  static const String _serviceProvider = "Service Provider";
  static const String _about = "About";
  static const String _services = "Services";
  static const String _staffs = "Staffs";
  static const String _totalStaff = "Total Staff";
  static const String _serviceArea = "Service Area";
  static const String _added = "Added";
  static const String _categories = "Categories";
  static const String _searchOrChoseCategory = "Search or Chose a Category";
  static const String _seeAll = "See All";
  static const String _choseLocation = "Choose Location";
  static const String _useThisLocation = "Use This Location";
  static const String _searchLocation = "Search location";
  static const String _selectALocationByMovingMap =
      "Select a location by moving the map";
  static const String _choosePaymentMethod = "Choose Payment Method";
  static const String _applyCoupon = "Apply Coupon";
  static const String _enterCode = "Enter code";
  static const String _payAndConfirmOrder = "Pay & Confirm Order";
  static const String _changeLanguage = "Change Language";
  static const String _language = "Language";
  static const String _darkMode = "Dark Mode";
  static const String _cancelOrder = "Cancel Order";
  static const String _jobList = "Job List";
  static const String _providerDetails = "Provider details";
  static const String _preferredStaffs = "Preferred Staffs";
  static const String _passwordChangedSuccessfully =
      "Password changed successfully";
  static const String _signOutSuccessful = "Sign out successfully";
  static const String _offers = "Offers";
  static const String _selectFromMap = "Select from map";
  static const String _enterAddress = "Enter address";
  static const String _addressAddedSuccessfully = "Address added successfully";
  static const String _editAddress = "Edit address";
  static const String _addressEditedSuccessfully =
      "Address edited successfully";
  static const String _removeAddress = "Remove address";
  static const String _addressRemovedSuccessfully =
      "Address removed successfully";
  static const String _mapMoveNote = "Long press and move to select location.";
  static const String _noJobFound = "No jobs found";
  static const String _selectAddress = "Select address";
  static const String _enterValidAmount = "Enter a valid amount";
  static const String _titleMustContainMoreCharacter =
      "Title must contain more then 10 characters";
  static const String _descriptionLengthValidation =
      "Description must contain more then 20 characters";
  static const String _serviceDetails = "Service Details";
  static const String _selectASchedule = "Select a schedule";
  static const String _selectStaff = "Select staff";
  static const String _note = "Note";
  static const String _addedToCartSuccessfully = "Added to cart successfully";
  static const String _removeFromCart = "Remove from Cart";
  static const String _updateItem = "Update Item";
  static const String _updatedSuccessfully = "Updated successfully";
  static const String _itemRemovedSuccessfully = "Item removed successfully";
  static const String _selectPaymentInfo = "Select payment info";
  static const String _delivered = "Delivered";
  static const String _declined = "Declined";
  static const String _orderNotFound = "Order not found";
  static const String _paymentUpdateFailed = "Payment update failed";
  static const String _na = "N/A";
  static const String _open = "Open";
  static const String _urgent = "Urgent";
  static const String _normal = "Normal";
  static const String _high0 = "High";
  static const String _low0 = "Low";
  static const String _stDepartmentsUrl = "Departments";
  static const String _ticketCreatedSuccessfully =
      "Ticket created successfully";
  static const String _ticketTittleLeastChar =
      "Title should be more then 4 characters";
  static const String _writeMessage = "Write message...";
  static const String _noFileChosen = "No file choosen";
  static const String _notifyViaMail = "Notify via mail";
  static const String _send = "Send";
  static const String _downloadAttachment = "Download attachment";
  static const String _otpSendToMailSuccessfully =
      "Otp sent to mail successfully";
  static const String _aboutYou = "About You";
  static const String _aboutYouDesc =
      "The name & date of birth should exactly match with your national identity card.";
  static const String _enterAValidName = "Enter a valid name";
  static const String _dateOfBirth = "Date of Birth";
  static const String _profileSetup = "Profile setup";
  static const String _profileSetupComplete = "Profile setup complete";
  static const String _fileSizeExceeded = "File size exceeded";
  static const String _profileInfoUpdated = "Profile info updated";
  static const String _selectImage = "Select image";
  static const String _selectAReason = "Select a reason";
  static const String _reason = "Reason";
  static const String _accountDeletedSuccessfully =
      "Account deleted successfully";
  static const String _invalidEmailAddress = "Invalid email address";
  static const String _changedEmailSuccessfully = "Changed email successfully";
  static const String _phoneNumberHint = "+12300000000000";
  static const String _changedPhoneSuccessfully = "Change phone successfully";
  static const String _noOrderCompletedYet = "No order completed yet";
  static const String _providers = "Providers";
  static const String _setNewPassword = "Set New Password";
  static const String _payNow = "Pay Now";
  static const String _paymentSuccess = "Payment Success";
  static const String _paymentProcessedSuccessfully =
      "Payment processed successfully";
  static const String _clearCart = "Clear All";
  static const String _clear = "Clear";
  static const String _offerDetails = "Offer Details";
  static const String _providerHiredSuccessfully =
      "Provider hired Successfully";
  static const String _paymentFailed = "Payment Failed";
  static const String _providerHiredButPaymentProcessFailed =
      "Provider was hired successfully but the payment process have failed. Retry from order details or open a support ticket.";
  static const String _contact = "Contact";
  static const String _enterAValidPhoneNumber = "Enter a valid phone number";
  static const String _requestHistory = "Completion request history";
  static const String _requestedForOrderCompletion =
      "Requested for order completion";
  static const String _orderCompletionRequestAccepted =
      "Order completion request accepted.";
  static const String _orderCompletionRequestDeclined =
      "Order completion request declined.";
  static const String _requestInPending = "Request in pending";
  static const String _completeOrder = "Complete Order";
  static const String _declineRequest = "Decline Request";
  static const String _accept = "Accept";
  static const String _decline = "Decline";
  static const String _enterAValidReason = "Enter a valid reason.";
  static const String _enterOrderDeclineReason = "Enter order decline reason.";
  static const String _suspended = "Suspended";
  static const String _submitReview = "Submit Review";
  static const String _submit = "Submit";
  static const String _comment = "Comment";
  static const String _describeYourExperience = "Describe your experience";
  static const String _overallRatingForCustomer = "OVerall rating for customer";
  static const String _taxInfo = "Tax info";
  static const String _reviewSubmittedSuccessfully =
      "Review submitted successfully";
  static const String _enterAComment = "Enter a comment about your experience";
  static const String _myReview = "My review";
  static const String _providersReview = "Provider's review";
  static const String _publish = "Publish";
  static const String _jobPublishStatusChangedSuccessfully =
      "Job publish status changed successfully";
  static const String _jobPublished = "Job Published";
  static const String _changeO = "Change";
  static const String _featuredServices = "Featured Services";
  static const String _popularServices = "Popular Services";
  static const String _searchService = "Search Service";
  static const String _couponAppliedSuccessfully =
      "Coupon applied successfully";
  static const String _chatList = "Chat list";
  static const String _noConversationFound = "No conversation found.";
  static const String _attachFile = "Attach file";
  static const String _selectLanguage = "Select language";
  static const String _you = "You";
  static const String _providerNotFound = "Provider not found";
  static const String _cod = "COD";
  static const String _editJob = "Edit Job";
  static const String _loadingImages = "Loading images";
  static const String _jobEditedSuccessfully = "Job edited successfully";
  static const String _job = "Job";
  static const String _serviceNotFound = "Service not found";
  static const String _verificationFailed = "Verification failed!";
  static const String _accountCreatedButVerificationFailed =
      "Account created, but your email wasn't verified. You can sign in later using the same email and password, and verify then.";
  static const String _editNotAllowedAfterProviderHired =
      "Editing is not allowed after a provider is hired.";
  static const String _sessionExpired = "Session expired";
  static const String _enterValidAddress = "Enter a valid address.";
  static const String _selectACity = "Select a city";
  static const String _selectAnArea = "Select an area";
  static const String _languageChangesSuccessfully =
      "Language changed successfully";
  static const String _noOrdersFound = "No orders found!";
  static const String _noFavoritesFound = "No favorites found!";
  static const String _noTicketsFound = "No tickets found";
  static const String _noRatingsFound = "No ratings found!";
  static const String _relatedServices = "Related services";
  static const String _sold = "Sold";
  static const String _noFaqAdded = "No FAQ added";
  static const String _noAddonsFound = "No addons found!";
  static const String _noStaffAdded = "No staff added!";
  static const String _noOffersFound = "No offers found!";
  static const String _noServiceFound = "No service found!";
  static const String _offerRejectedSuccessfully =
      "Offer rejected successfully";
  static const String _hello = "Hello 👋";
  static const String _noServiceAddedYet = "No service added yet.";
  static const String _deleteJobConfirmation = "Confirm Job Deletion?";
  static const String _deleteJobDescription =
      "Are you sure you want to delete this job? This action cannot be undone, and all associated data will be permanently removed.";
  static const String _jobDeletedSuccessfully = "Job deleted successfully";
  static const String _openingMap = "Opening Map...";
  static const String _officialPlatformProvider = "Official Platform Provider";
  static const String _refundPaymentMethod = "Refund payment method";
  static const String _updateRefundInfo = "Update refund info";
  static const String _orderCancelledSuccessfully = "Order cancelled successfully.";
  static const String _selectAPaymentMethod = "Select a Payment Method";
  static const String _status = "Status";
  static const String _requestRefund = "Request Refund";
  static const String _sendRequest = "Send Request";
  static const String _refundRequestSentSuccessfully = "Refund request sent successfully.";
  static const String _refunds = "Refunds";
  static const String _infoUpdatedSuccessfully = "Info updated successfully.";
  static const String _somethingWentWrong = "Something went wrong!";
  static const String _updatePaymentInfo = "Update payment info";
  static const String _update0 = "Update";
  static const String _noPaymentInfoFound = "No payment info found.";
  static const String _refundAmount = "Refund amount";
  static const String _status0 = "Status";
  static const String _refundRequest = "Refund Request";
  static const String _refunded = "Refunded";
  static const String _notSpecified = "Not specified.";
//variable ends here

//getter starts here
  static String get notSpecified => _notSpecified.tr();
  static String get refunded => _refunded.tr();
  static String get refundRequest => _refundRequest.tr();
  static String get status0 => _status0.tr();
  static String get refundAmount => _refundAmount.tr();
  static String get noPaymentInfoFound => _noPaymentInfoFound.tr();
  static String get update0 => _update0.tr();
  static String get updatePaymentInfo => _updatePaymentInfo.tr();
  static String get somethingWentWrong => _somethingWentWrong.tr();
  static String get infoUpdatedSuccessfully => _infoUpdatedSuccessfully.tr();
  static String get refunds => _refunds.tr();
  static String get refundRequestSentSuccessfully => _refundRequestSentSuccessfully.tr();
  static String get sendRequest => _sendRequest.tr();
  static String get requestRefund => _requestRefund.tr();
  static String get status => _status.tr();
  static String get selectAPaymentMethod => _selectAPaymentMethod.tr();
  static String get orderCancelledSuccessfully => _orderCancelledSuccessfully.tr();
  static String get updateRefundInfo => _updateRefundInfo.tr();
  static String get refundPaymentMethod => _refundPaymentMethod.tr();
  static String get officialPlatformProvider => _officialPlatformProvider.tr();
  static String get openingMap => _openingMap.tr();
  static String get jobDeletedSuccessfully => _jobDeletedSuccessfully.tr();
  static String get deleteJobDescription => _deleteJobDescription.tr();
  static String get deleteJobConfirmation => _deleteJobConfirmation.tr();
  static String get noServiceAddedYet => _noServiceAddedYet.tr();
  static String get hello => _hello.tr();
  static String get offerRejectedSuccessfully =>
      _offerRejectedSuccessfully.tr();
  static String get noServiceFound => _noServiceFound.tr();
  static String get noOffersFound => _noOffersFound.tr();
  static String get noStaffAdded => _noStaffAdded.tr();
  static String get noAddonsFound => _noAddonsFound.tr();
  static String get noFaqAdded => _noFaqAdded.tr();
  static String get sold => _sold.tr();
  static String get relatedServices => _relatedServices.tr();
  static String get noRatingsFound => _noRatingsFound.tr();
  static String get noTicketsFound => _noTicketsFound.tr();
  static String get noFavoritesFound => _noFavoritesFound.tr();
  static String get noOrdersFound => _noOrdersFound.tr();
  static String get languageChangesSuccessfully =>
      _languageChangesSuccessfully.tr();
  static String get selectAnArea => _selectAnArea.tr();
  static String get selectACity => _selectACity.tr();
  static String get enterValidAddress => _enterValidAddress.tr();
  static String get sessionExpired => _sessionExpired.tr();
  static String get editNotAllowedAfterProviderHired =>
      _editNotAllowedAfterProviderHired.tr();
  static String get accountCreatedButVerificationFailed =>
      _accountCreatedButVerificationFailed.tr();
  static String get verificationFailed => _verificationFailed.tr();
  static String get serviceNotFound => _serviceNotFound.tr();
  static String get job => _job.tr();
  static String get jobEditedSuccessfully => _jobEditedSuccessfully.tr();
  static String get loadingImages => _loadingImages.tr();
  static String get editJob => _editJob.tr();
  static String get cod => _cod.tr();
  static String get providerNotFound => _providerNotFound.tr();
  static String get you => _you.tr();
  static String get selectLanguage => _selectLanguage.tr();
  static String get attachFile => _attachFile.tr();
  static String get noConversationFound => _noConversationFound.tr();
  static String get chatList => _chatList.tr();
  static String get couponAppliedSuccessfully =>
      _couponAppliedSuccessfully.tr();
  static String get searchService => _searchService.tr();
  static String get popularServices => _popularServices.tr();
  static String get featuredServices => _featuredServices.tr();
  static String get changeO => _changeO.tr();
  static String get jobPublished => _jobPublished.tr();
  static String get jobPublishStatusChangedSuccessfully =>
      _jobPublishStatusChangedSuccessfully.tr();
  static String get publish => _publish.tr();
  static String get providersReview => _providersReview.tr();
  static String get myReview => _myReview.tr();
  static String get enterAComment => _enterAComment.tr();
  static String get reviewSubmittedSuccessfully =>
      _reviewSubmittedSuccessfully.tr();
  static String get taxInfo => _taxInfo.tr();
  static String get overallRatingForCustomer => _overallRatingForCustomer.tr();
  static String get describeYourExperience => _describeYourExperience.tr();
  static String get comment => _comment.tr();
  static String get submit => _submit.tr();
  static String get submitReview => _submitReview.tr();
  static String get suspended => _suspended.tr();
  static String get enterOrderDeclineReason => _enterOrderDeclineReason.tr();
  static String get enterAValidReason => _enterAValidReason.tr();
  static String get decline => _decline.tr();
  static String get accept => _accept.tr();
  static String get declineRequest => _declineRequest.tr();
  static String get completeOrder => _completeOrder.tr();
  static String get requestInPending => _requestInPending.tr();
  static String get orderCompletionRequestDeclined =>
      _orderCompletionRequestDeclined.tr();
  static String get orderCompletionRequestAccepted =>
      _orderCompletionRequestAccepted.tr();
  static String get requestedForOrderCompletion =>
      _requestedForOrderCompletion.tr();
  static String get requestHistory => _requestHistory.tr();
  static String get enterAValidPhoneNumber => _enterAValidPhoneNumber.tr();
  static String get contact => _contact.tr();
  static String get providerHiredButPaymentProcessFailed =>
      _providerHiredButPaymentProcessFailed.tr();
  static String get paymentFailed => _paymentFailed.tr();
  static String get providerHiredSuccessfully =>
      _providerHiredSuccessfully.tr();
  static String get offerDetails => _offerDetails.tr();
  static String get clear => _clear.tr();
  static String get clearCart => _clearCart.tr();
  static String get paymentProcessedSuccessfully =>
      _paymentProcessedSuccessfully.tr();
  static String get paymentSuccess => _paymentSuccess.tr();
  static String get payNow => _payNow.tr();
  static String get setNewPassword => _setNewPassword.tr();
  static String get providers => _providers.tr();
  static String get noOrderCompletedYet => _noOrderCompletedYet.tr();
  static String get changedPhoneSuccessfully => _changedPhoneSuccessfully.tr();
  static String get phoneNumberHint => _phoneNumberHint.tr();
  static String get changedEmailSuccessfully => _changedEmailSuccessfully.tr();
  static String get invalidEmailAddress => _invalidEmailAddress.tr();
  static String get accountDeletedSuccessfully =>
      _accountDeletedSuccessfully.tr();
  static String get reason => _reason.tr();
  static String get selectAReason => _selectAReason.tr();
  static String get selectImage => _selectImage.tr();
  static String get profileInfoUpdated => _profileInfoUpdated.tr();
  static String get fileSizeExceeded => _fileSizeExceeded.tr();
  static String get profileSetupComplete => _profileSetupComplete.tr();
  static String get profileSetup => _profileSetup.tr();
  static String get dateOfBirth => _dateOfBirth.tr();
  static String get enterAValidName => _enterAValidName.tr();
  static String get aboutYouDesc => _aboutYouDesc.tr();
  static String get aboutYou => _aboutYou.tr();
  static String get otpSendToMailSuccessfully =>
      _otpSendToMailSuccessfully.tr();
  static String get downloadAttachment => _downloadAttachment.tr();
  static String get send => _send.tr();
  static String get notifyViaMail => _notifyViaMail.tr();
  static String get noFileChosen => _noFileChosen.tr();
  static String get writeMessage => _writeMessage.tr();
  static String get ticketTittleLeastChar => _ticketTittleLeastChar.tr();
  static String get ticketCreatedSuccessfully =>
      _ticketCreatedSuccessfully.tr();
  static String get selectDepartment => _selectDepartment.tr();
  static String get stDepartmentsUrl => _stDepartmentsUrl.tr();
  static String get low0 => _low0.tr();
  static String get high0 => _high0.tr();
  static String get normal => _normal.tr();
  static String get urgent => _urgent.tr();
  static String get open => _open.tr();
  static String get na => _na.tr();
  static String get paymentUpdateFailed => _paymentUpdateFailed.tr();
  static String get orderNotFound => _orderNotFound.tr();
  static String get declined => _declined.tr();
  static String get delivered => _delivered.tr();
  static String get selectPaymentInfo => _selectPaymentInfo.tr();
  static String get itemRemovedSuccessfully => _itemRemovedSuccessfully.tr();
  static String get updatedSuccessfully => _updatedSuccessfully.tr();
  static String get updateItem => _updateItem.tr();
  static String get removeFromCart => _removeFromCart.tr();
  static String get addedToCartSuccessfully => _addedToCartSuccessfully.tr();
  static String get note => _note.tr();
  static String get selectStaff => _selectStaff.tr();
  static String get selectASchedule => _selectASchedule.tr();
  static String get serviceDetails => _serviceDetails.tr();
  static String get descriptionLengthValidation =>
      _descriptionLengthValidation.tr();
  static String get titleMustContainMoreCharacter =>
      _titleMustContainMoreCharacter.tr();
  static String get enterValidAmount => _enterValidAmount.tr();
  static String get selectAddress => _selectAddress.tr();
  static String get noJobFound => _noJobFound.tr();
  static String get mapMoveNote => _mapMoveNote.tr();
  static String get addressRemovedSuccessfully =>
      _addressRemovedSuccessfully.tr();
  static String get removeAddress => _removeAddress.tr();
  static String get addressEditedSuccessfully =>
      _addressEditedSuccessfully.tr();
  static String get editAddress => _editAddress.tr();
  static String get addressAddedSuccessfully => _addressAddedSuccessfully.tr();
  static String get enterAddress => _enterAddress.tr();
  static String get selectFromMap => _selectFromMap.tr();
  static String get allOffers => _allOffers.tr();
  static String get offers => _offers.tr();
  static String get signOutSuccessful => _signOutSuccessful.tr();
  static String get passwordChangedSuccessfully =>
      _passwordChangedSuccessfully.tr();
  static String get preferredStaffs => _preferredStaffs.tr();
  static String get providerDetails => _providerDetails.tr();
  static String get jobList => _jobList.tr();
  static String get cancelOrder => _cancelOrder.tr();
  static String get orderDetails => _orderDetails.tr();
  static String get darkMode => _darkMode.tr();
  static String get language => _language.tr();
  static String get changeLanguage => _changeLanguage.tr();
  static String get payAndConfirmOrder => _payAndConfirmOrder.tr();
  static String get enterCode => _enterCode.tr();
  static String get applyCoupon => _applyCoupon.tr();
  static String get choosePaymentMethod => _choosePaymentMethod.tr();
  static String get selectALocationByMovingMap =>
      _selectALocationByMovingMap.tr();
  static String get searchLocation => _searchLocation.tr();
  static String get useThisLocation => _useThisLocation.tr();
  static String get choseLocation => _choseLocation.tr();
  static String get seeAll => _seeAll.tr();
  static String get searchOrChoseCategory => _searchOrChoseCategory.tr();
  static String get categories => _categories.tr();
  static String get added => _added.tr();
  static String get serviceArea => _serviceArea.tr();
  static String get totalStaff => _totalStaff.tr();
  static String get staffs => _staffs.tr();
  static String get services => _services.tr();
  static String get about => _about.tr();
  static String get serviceProvider => _serviceProvider.tr();
  static String get enterTheOTP => _enterTheOTP.tr();
  static String get enterValidEmailAddress => _enterValidEmailAddress.tr();
  static String get youHaveSignedUpSuccessfully =>
      _youHaveSignedUpSuccessfully.tr();
  static String get clickToSelectPhoto => _clickToSelectPhoto.tr();
  static String get skipForLater => _skipForLater.tr();
  static String get uploadProfilePhoto => _uploadProfilePhoto.tr();
  static String get uploadYourProfilePhoto => _uploadYourProfilePhoto.tr();
  static String get verifyEmail => _verifyEmail.tr();
  static String get retypePassword => _retypePassword.tr();
  static String get signUpWithApple => _signUpWithApple.tr();
  static String get signUpWithFacebook => _signUpWithFacebook.tr();
  static String get signUpWithGoogle => _signUpWithGoogle.tr();
  static String get haveAccount => _haveAccount.tr();
  static String get byProceedingIAgreeToThe => _byProceedingIAgreeToThe.tr();
  static String get or => _or.tr();
  static String get signInWithApple => _signInWithApple.tr();
  static String get signInWithFacebook => _signInWithFacebook.tr();
  static String get signInWithGoogle => _signInWithGoogle.tr();
  static String get signInFailed => _signInFailed.tr();
  static String get otpSignIn => _otpSignIn.tr();
  static String get signUp => _signUp.tr();
  static String get doNotHaveAccount => _doNotHaveAccount.tr();
  static String get rememberMe => _rememberMe.tr();
  static String get forgotPassword => _forgotPassword.tr();
  static String get enterPassword => _enterPassword.tr();
  static String get password => _password.tr();
  static String get signIn => _signIn.tr();
  static String get noMessageFound => _noMessageFound.tr();
  static String get pullDown => _pullDown.tr();
  static String get pleaseWriteMessageOrSelectAFile =>
      _pleaseWriteMessageOrSelectAFile.tr();
  static String get sendMessage => _sendMessage.tr();
  static String get schedule => _schedule.tr();
  static String get id => _id.tr();
  static String get requestToCancelDesc => _requestToCancelDesc.tr();
  static String get downloadInvoice => _downloadInvoice.tr();
  static String get requestToCancel => _requestToCancel.tr();
  static String get orderStatus => _orderStatus.tr();
  static String get paymentStatus => _paymentStatus.tr();
  static String get billed => _billed.tr();
  static String get bookingSuccessful => _bookingSuccessful.tr();
  static String get shareDetails => _shareDetails.tr();
  static String get orderSummery => _orderSummery.tr();
  static String get expireDate => _expireDate.tr();
  static String get cvvCvc => _cvvCvc.tr();
  static String get invalidCardNumber => _invalidCardNumber.tr();
  static String get cardNumber => _cardNumber.tr();
  static String get enterUsername => _enterUsername.tr();
  static String get username => _username.tr();
  static String get paymentGateway => _paymentGateway.tr();
  static String get loadingFailed => _loadingFailed.tr();
  static String get invalidDeveloperKeys => _invalidDeveloperKeys.tr();
  static String get yes => _yes.tr();
  static String get yourPaymentWillTerminate => _yourPaymentWillTerminate.tr();
  static String get errorOccurred => _errorOccurred.tr();
  static String get connectionTimeout => _connectionTimeout.tr();
  static String get cart => _cart.tr();
  static String get proceedToPay => _proceedToPay.tr();
  static String get addToCart => _addToCart.tr();
  static String get package => _package.tr();
  static String get choseStaff => _choseStaff.tr();
  static String get select => _select.tr();
  static String get addNote => _addNote.tr();
  static String get bookingNoteExmp => _bookingNoteExmp.tr();
  static String get availableSlots => _availableSlots.tr();
  static String get selectDateAndSchedule => _selectDateAndSchedule.tr();
  static String get dateAndSchedule => _dateAndSchedule.tr();
  static String get addons => _addons.tr();
  static String get serviceAddonsAndDate => _serviceAddonsAndDate.tr();
  static String get bookService => _bookService.tr();
  static String get cancellationPolicy => _cancellationPolicy.tr();
  static String get safetyAndSecurity => _safetyAndSecurity.tr();
  static String get whatIsNotIncluded => _whatIsNotIncluded.tr();
  static String get ourOffers => _ourOffers.tr();
  static String get faq => _faq.tr();
  static String get reviews => _reviews.tr();
  static String get overview => _overview.tr();
  static String get office => _office.tr();
  static String get emergencyPhoneNumber => _emergencyPhoneNumber.tr();
  static String get zipCode => _zipCode.tr();
  static String get enterZipCode => _enterZipCode.tr();
  static String get addAddress => _addAddress.tr();
  static String get newAddress => _newAddress.tr();
  static String get priority => _priority.tr();
  static String get selectPriority => _selectPriority.tr();
  static String get department => _department.tr();
  static String get enterTitle => _enterTitle.tr();
  static String get title => _title.tr();
  static String get createTicket => _createTicket.tr();
  static String get closed => _closed.tr();
  static String get active => _active.tr();
  static String get newTicket => _newTicket.tr();
  static String get delete => _delete.tr();
  static String get passwordDidNotMatch => _passwordDidNotMatch.tr();
  static String get confirmPassword => _confirmPassword.tr();
  static String get reEnterNewPassword => _reEnterNewPassword.tr();
  static String get enterNewPassword => _enterNewPassword.tr();
  static String get newPassword => _newPassword.tr();
  static String get enterYourCurrentPassword => _enterYourCurrentPassword.tr();
  static String get currentPassword => _currentPassword.tr();
  static String get enterYourPhoneVerificationCode =>
      _enterYourPhoneVerificationCode.tr();
  static String get enterPhone => _enterPhone.tr();
  static String get verificationCodeWillBeSentToTheNewPhone =>
      _verificationCodeWillBeSentToTheNewPhone.tr();
  static String get enterEmail => _enterEmail.tr();
  static String get resendCode => _resendCode.tr();
  static String get wrongOTPCode => _wrongOTPCode.tr();
  static String get sendAgain => _sendAgain.tr();
  static String get resend => _resend.tr();
  static String get didNotReceived => _didNotReceived.tr();
  static String get doNotShareCode => _doNotShareCode.tr();
  static String get enterYourVerificationCode =>
      _enterYourVerificationCode.tr();
  static String get verificationCode => _verificationCode.tr();
  static String get passwordResetSuccessful => _passwordResetSuccessful.tr();
  static String get resetPassword => _resetPassword.tr();
  static String get sendingOtpToMail => _sendingOtpToMail.tr();
  static String get sendVerificationCode => _sendVerificationCode.tr();
  static String get enterNewEmail => _enterNewEmail.tr();
  static String get email => _email.tr();
  static String get verificationCodeWillBeSentToTheNewEmail =>
      _verificationCodeWillBeSentToTheNewEmail.tr();
  static String get saveChanges => _saveChanges.tr();
  static String get enterLastName => _enterLastName.tr();
  static String get lastName => _lastName.tr();
  static String get enterFirstName => _enterFirstName.tr();
  static String get firstName => _firstName.tr();
  static String get changePassword => _changePassword.tr();
  static String get changePhone => _changePhone.tr();
  static String get changeEmail => _changeEmail.tr();
  static String get editInformation => _editInformation.tr();
  static String get changeImage => _changeImage.tr();
  static String get personalInformation => _personalInformation.tr();
  static String get signOut => _signOut.tr();
  static String get deleteAccount => _deleteAccount.tr();
  static String get languages => _languages.tr();
  static String get paymentMethods => _paymentMethods.tr();
  static String get addresses => _addresses.tr();
  static String get notifications => _notifications.tr();
  static String get supportTicket => _supportTicket.tr();
  static String get ratingAndReviews => _ratingAndReviews.tr();
  static String get totalOrders => _totalOrders.tr();
  static String get completedOrders => _completedOrders.tr();
  static String get pendingOrders => _pendingOrders.tr();
  static String get favoriteServices => _favoriteServices.tr();
  static String get emailUsernameValidateText =>
      _emailUsernameValidateText.tr();
  static String get signedInSuccessfully => _signedInSuccessfully.tr();
  static String get serviceAddress => _serviceAddress.tr();
  static String get serviceDate => _serviceDate.tr();
  static String get jobPostingSuccessDescription =>
      _jobPostingSuccessDescription.tr();
  static String get congrats => _congrats.tr();
  static String get areYouSure => _areYouSure.tr();
  static String get postJob => _postJob.tr();
  static String get edit => _edit.tr();
  static String get back => _back.tr();
  static String get uploadPhotosSuggestion => _uploadPhotosSuggestion.tr();
  static String get uploadGalleryPhotos => _uploadGalleryPhotos.tr();
  static String get remove => _remove.tr();
  static String get view => _view.tr();
  static String get addPhoto => _addPhoto.tr();
  static String get enterDescription => _enterDescription.tr();
  static String get description => _description.tr();
  static String get enterYourBudget => _enterYourBudget.tr();
  static String get jobDescriptionSectionSuggestion =>
      _jobDescriptionSectionSuggestion.tr();
  static String get jobDescription => _jobDescription.tr();
  static String get date => _date.tr();
  static String get time => _time.tr();
  static String get noTimeSelected => _noTimeSelected.tr();
  static String get failedToSelectTime => _failedToSelectTime.tr();
  static String get timeSelected => _timeSelected.tr();
  static String get selectTime => _selectTime.tr();
  static String get dateSelectFailed => _dateSelectFailed.tr();
  static String get dateSelected => _dateSelected.tr();
  static String get where0 => _where0.tr();
  static String get whereDoYouNeedThis => _whereDoYouNeedThis.tr();
  static String get searchCategory => _searchCategory.tr();
  static String get selectCategory => _selectCategory.tr();
  static String get enterJobTitle => _enterJobTitle.tr();
  static String get jobTitle => _jobTitle.tr();
  static String get jobBasicInfoSuggestion => _jobBasicInfoSuggestion.tr();
  static String get total => _total.tr();
  static String get vat => _vat.tr();
  static String get discount => _discount.tr();
  static String get subtotal => _subtotal.tr();
  static String get offered => _offered.tr();
  static String get phone => _phone.tr();
  static String get summary => _summary.tr();
  static String get hireNow => _hireNow.tr();
  static String get reject => _reject.tr();
  static String get coverLetter => _coverLetter.tr();
  static String get notVerified => _notVerified.tr();
  static String get verified => _verified.tr();
  static String get verificationStatus => _verificationStatus.tr();
  static String get address => _address.tr();
  static String get memberSince => _memberSince.tr();
  static String get jobCompleted => _jobCompleted.tr();
  static String get applicationDetails => _applicationDetails.tr();
  static String get completionRate => _completionRate.tr();
  static String get match => _match.tr();
  static String get rejected => _rejected.tr();
  static String get hired => _hired.tr();
  static String get shortlisted => _shortlisted.tr();
  static String get applicants => _applicants.tr();
  static String get showLess => _showLess.tr();
  static String get showMore => _showMore.tr();
  static String get where => _where.tr();
  static String get when => _when.tr();
  static String get jobDetails => _jobDetails.tr();
  static String get applied => _applied.tr();
  static String get budget => _budget.tr();
  static String get allJobs => _allJobs.tr();
  static String get file => _file.tr();
  static String get messages => _messages.tr();
  static String get orderList => _orderList.tr();
  static String get canceled => _canceled.tr();
  static String get complete => _complete.tr();
  static String get inProgress => _inProgress.tr();
  static String get accepted => _accepted.tr();
  static String get pending => _pending.tr();
  static String get payment => _payment.tr();
  static String get booking => _booking.tr();
  static String get all => _all.tr();
  static String get results => _results.tr();
  static String get applyFilter => _applyFilter.tr();
  static String get resetFilter => _resetFilter.tr();
  static String get serviceUnits => _serviceUnits.tr();
  static String get searchCity => _searchCity.tr();
  static String get selectCity => _selectCity.tr();
  static String get imLookingServiceIn => _imLookingServiceIn.tr();
  static String get priceRange => _priceRange.tr();
  static String get rating => _rating.tr();
  static String get handyman => _handyman.tr();
  static String get service => _service.tr();
  static String get iamLookingFor => _iamLookingFor.tr();
  static String get didNotFindWhatLookingFor => _didNotFindWhatLookingFor.tr();
  static String get postAJob => _postAJob.tr();
  static String get sliders => _sliders.tr();
  static String get category => _category.tr();
  static String get profile => _profile.tr();
  static String get jobs => _jobs.tr();
  static String get message => _message.tr();
  static String get orders => _orders.tr();
  static String get home => _home.tr();
  static String get pressAgainToExit => _pressAgainToExit.tr();
  static String get continueO => _continue.tr();
  static String get skip => _skip.tr();
  static String get privacyPolicy => _privacyPolicy.tr();
  static String get and => _and.tr();
  static String get termsAndConditions => _termsAndConditions.tr();
  static String get byCreatingAnAccountYouAgreeToThe =>
      _byCreatingAnAccountYouAgreeToThe.tr();
  static String get selectDate => _selectDate.tr();
  static String get passLowerCaseWarning => _passLowerCaseWarning.tr();
  static String get passDigitWarning => _passDigitWarning.tr();
  static String get passCharacterWarning => _passCharacterWarning.tr();
  static String get passUpperCaseWarning => _passUpperCaseWarning.tr();
  static String get passLeastCharWarning => _passLeastCharWarning.tr();
  static String get selectState => _selectState.tr();
  static String get searchState => _searchState.tr();
  static String get requestTimeOut => _requestTimeOut.tr();
  static String get invalidUrl => _invalidUrl.tr();
  static String get orderId => _orderId.tr();
  static String get okay => _okay.tr();
  static String get area => _area.tr();
  static String get state => _state.tr();
  static String get city => _city.tr();
  static String get selectAState => _selectAState.tr();
  static String get searchArea => _searchArea.tr();
  static String get noResultFound => _noResultFound.tr();
  static String get selectArea => _selectArea.tr();
  static String get selectFile => _selectFile.tr();
  static String get fileRemoved => _fileRemoved.tr();
  static String get fileSelected => _fileSelected.tr();
  static String get fileSelectFailed => _fileSelectFailed.tr();
  static String get noSelectedFile => _noSelectedFile.tr();
  static String get clearFile => _clearFile.tr();
  static String get oops => _oops.tr();
  static String get noConnectionFound => _noConnectionFound.tr();
  static String get retry => _retry.tr();
  static String get pullUp => _pullUp.tr();
  static String get translatingText => _translatingText.tr();
  static String get cancel => _cancel.tr();

  static final stringsMap = {
    _state: _state,
    _city: _city,
    _selectAState: _selectAState,
    _searchArea: _searchArea,
    _noResultFound: _noResultFound,
    _selectArea: _selectArea,
    _selectFile: _selectFile,
    _fileRemoved: _fileRemoved,
    _fileSelected: _fileSelected,
    _fileSelectFailed: _fileSelectFailed,
    _noSelectedFile: _noSelectedFile,
    _clearFile: _clearFile,
    _oops: _oops,
    _noConnectionFound: _noConnectionFound,
    _retry: _retry,
    _pullUp: _pullUp,
    _translatingText: _translatingText,
    _cancel: _cancel,
    _okay: _okay,
    _orderId: _orderId,
    _invalidUrl: _invalidUrl,
    _requestTimeOut: _requestTimeOut,
    _searchState: _searchState,
    _selectState: _selectState,
    _selectDate: _selectDate,
    _byCreatingAnAccountYouAgreeToThe: _byCreatingAnAccountYouAgreeToThe,
    _termsAndConditions: _termsAndConditions,
    _and: _and,
    _privacyPolicy: _privacyPolicy,
    _skip: _skip,
    _continue: _continue,
    _pressAgainToExit: _pressAgainToExit,
    _home: _home,
    _orders: _orders,
    _message: _message,
    _jobs: _jobs,
    _profile: _profile,
    _category: _category,
    _sliders: _sliders,
    _postAJob: _postAJob,
    _didNotFindWhatLookingFor: _didNotFindWhatLookingFor,
    _iamLookingFor: _iamLookingFor,
    _service: _service,
    _handyman: _handyman,
    _rating: _rating,
    _priceRange: _priceRange,
    _imLookingServiceIn: _imLookingServiceIn,
    _selectCity: _selectCity,
    _searchCity: _searchCity,
    _serviceUnits: _serviceUnits,
    _resetFilter: _resetFilter,
    _applyFilter: _applyFilter,
    _results: _results,
    _all: _all,
    _booking: _booking,
    _payment: _payment,
    _pending: _pending,
    _accepted: _accepted,
    _inProgress: _inProgress,
    _complete: _complete,
    _canceled: _canceled,
    _orderList: _orderList,
    _messages: _messages,
    _file: _file,
    _allJobs: _allJobs,
    _budget: _budget,
    _applied: _applied,
    _jobDetails: _jobDetails,
    _when: _when,
    _where: _where,
    _showMore: _showMore,
    _showLess: _showLess,
    _applicants: _applicants,
    _shortlisted: _shortlisted,
    _hired: _hired,
    _rejected: _rejected,
    _allOffers: _allOffers,
    _match: _match,
    _completionRate: _completionRate,
    _applicationDetails: _applicationDetails,
    _jobCompleted: _jobCompleted,
    _memberSince: _memberSince,
    _address: _address,
    _verificationStatus: _verificationStatus,
    _verified: _verified,
    _notVerified: _notVerified,
    _coverLetter: _coverLetter,
    _reject: _reject,
    _hireNow: _hireNow,
    _summary: _summary,
    _phone: _phone,
    _offered: _offered,
    _subtotal: _subtotal,
    _discount: _discount,
    _vat: _vat,
    _total: _total,
    _jobBasicInfoSuggestion: _jobBasicInfoSuggestion,
    _jobTitle: _jobTitle,
    _enterJobTitle: _enterJobTitle,
    _selectCategory: _selectCategory,
    _searchCategory: _searchCategory,
    _whereDoYouNeedThis: _whereDoYouNeedThis,
    _where0: _where0,
    _dateSelected: _dateSelected,
    _dateSelectFailed: _dateSelectFailed,
    _selectTime: _selectTime,
    _timeSelected: _timeSelected,
    _failedToSelectTime: _failedToSelectTime,
    _noTimeSelected: _noTimeSelected,
    _time: _time,
    _date: _date,
    _jobDescription: _jobDescription,
    _jobDescriptionSectionSuggestion: _jobDescriptionSectionSuggestion,
    _enterYourBudget: _enterYourBudget,
    _description: _description,
    _enterDescription: _enterDescription,
    _addPhoto: _addPhoto,
    _view: _view,
    _remove: _remove,
    _uploadGalleryPhotos: _uploadGalleryPhotos,
    _uploadPhotosSuggestion: _uploadPhotosSuggestion,
    _back: _back,
    _edit: _edit,
    _postJob: _postJob,
    _areYouSure: _areYouSure,
    _congrats: _congrats,
    _jobPostingSuccessDescription: _jobPostingSuccessDescription,
    _serviceDate: _serviceDate,
    _serviceAddress: _serviceAddress,
    _signedInSuccessfully: '',
    _emailUsernameValidateText: '',
    _orderDetails: '',
    _cancelOrder: '',
    _jobList: '',
    _providerDetails: '',
    _preferredStaffs: _preferredStaffs,
    _passwordChangedSuccessfully: _passwordChangedSuccessfully,
    _signOutSuccessful: _signOutSuccessful,
    _offers: _offers,
    _selectFromMap: _selectFromMap,
    _enterAddress: _enterAddress,
    _addressAddedSuccessfully: _addressAddedSuccessfully,
    _editAddress: _editAddress,
    _addressEditedSuccessfully: _addressEditedSuccessfully,
    _removeAddress: _removeAddress,
    _addressRemovedSuccessfully: _addressRemovedSuccessfully,
    _mapMoveNote: _mapMoveNote,
    _noJobFound: _noJobFound,
    _selectAddress: _selectAddress,
    _enterValidAmount: _enterValidAmount,
    _titleMustContainMoreCharacter: _titleMustContainMoreCharacter,
    _descriptionLengthValidation: _descriptionLengthValidation,
    _serviceDetails: _serviceDetails,
    _selectASchedule: _selectASchedule,
    _selectStaff: _selectStaff,
    _note: _note,
    _addedToCartSuccessfully: _addedToCartSuccessfully,
    _removeFromCart: _removeFromCart,
    _updateItem: _updateItem,
    _updatedSuccessfully: _updatedSuccessfully,
    _itemRemovedSuccessfully: _itemRemovedSuccessfully,
    _selectPaymentInfo: _selectPaymentInfo,
    _delivered: _delivered,
    _declined: _declined,
    _orderNotFound: _orderNotFound,
    _paymentUpdateFailed: _paymentUpdateFailed,
    _na: _na,
    _open: _open,
    _urgent: _urgent,
    _normal: _normal,
    _high0: _high0,
    _low0: _low0,
    _stDepartmentsUrl: _stDepartmentsUrl,
    _ticketCreatedSuccessfully: _ticketCreatedSuccessfully,
    _ticketTittleLeastChar: _ticketTittleLeastChar,
    _writeMessage: _writeMessage,
    _noFileChosen: _noFileChosen,
    _notifyViaMail: _notifyViaMail,
    _send: _send,
    _downloadAttachment: _downloadAttachment,
    _otpSendToMailSuccessfully: _otpSendToMailSuccessfully,
    _aboutYou: _aboutYou,
    _aboutYouDesc: _aboutYouDesc,
    _enterAValidName: _enterAValidName,
    _dateOfBirth: _dateOfBirth,
    _profileSetup: _profileSetup,
    _profileSetupComplete: _profileSetupComplete,
    _fileSizeExceeded: _fileSizeExceeded,
    _profileInfoUpdated: _profileInfoUpdated,
    _selectImage: _selectImage,
    _selectAReason: _selectAReason,
    _reason: _reason,
    _accountDeletedSuccessfully: _accountDeletedSuccessfully,
    _invalidEmailAddress: _invalidEmailAddress,
    _changedEmailSuccessfully: _changedEmailSuccessfully,
    _phoneNumberHint: _phoneNumberHint,
    _changedPhoneSuccessfully: _changedPhoneSuccessfully,
    _noOrderCompletedYet: _noOrderCompletedYet,
    _providers: _providers,
    _setNewPassword: _setNewPassword,
    _payNow: _payNow,
    _paymentSuccess: _paymentSuccess,
    _paymentProcessedSuccessfully: _paymentProcessedSuccessfully,
    _clearCart: _clearCart,
    _clear: _clear,
    _providerHiredSuccessfully: _providerHiredSuccessfully,
    _paymentFailed: _paymentFailed,
    _providerHiredButPaymentProcessFailed:
        _providerHiredButPaymentProcessFailed,
    _contact: _contact,
    _enterAValidPhoneNumber: _enterAValidPhoneNumber,
    _requestHistory: _requestHistory,
    _requestedForOrderCompletion: _requestedForOrderCompletion,
    _orderCompletionRequestAccepted: _orderCompletionRequestAccepted,
    _orderCompletionRequestDeclined: _orderCompletionRequestDeclined,
    _requestInPending: _requestInPending,
    _completeOrder: _completeOrder,
    _declineRequest: _declineRequest,
    _accept: _accept,
    _decline: _decline,
    _enterAValidReason: _enterAValidReason,
    _enterOrderDeclineReason: _enterOrderDeclineReason,
    _suspended: _suspended,
    _submitReview: _submitReview,
    _submit: _submit,
    _comment: _comment,
    _describeYourExperience: _describeYourExperience,
    _overallRatingForCustomer: _overallRatingForCustomer,
    _taxInfo: _taxInfo,
    _reviewSubmittedSuccessfully: _reviewSubmittedSuccessfully,
    _enterAComment: _enterAComment,
    _myReview: _myReview,
    _providersReview: _providersReview,
    _publish: _publish,
    _jobPublishStatusChangedSuccessfully: _jobPublishStatusChangedSuccessfully,
    _jobPublished: _jobPublished,
    _changeO: _changeO,
    _featuredServices: _featuredServices,
    _popularServices: _popularServices,
    _searchService: _searchService,
    _couponAppliedSuccessfully: _couponAppliedSuccessfully,
    _chatList: _chatList,
    _noConversationFound: _noConversationFound,
    _attachFile: _attachFile,
    _selectLanguage: _selectLanguage,
    _you: _you,
    _providerNotFound: _providerNotFound,
    _cod: _cod,
    _editJob: _editJob,
    _loadingImages: _loadingImages,
    _jobEditedSuccessfully: _jobEditedSuccessfully,
    _job: _job,
    _serviceNotFound: _serviceNotFound,
    _verificationFailed: _verificationFailed,
    _accountCreatedButVerificationFailed: _accountCreatedButVerificationFailed,
    _editNotAllowedAfterProviderHired: _editNotAllowedAfterProviderHired,
    _sessionExpired: _sessionExpired,
    _enterValidAddress: _enterValidAddress,
    _selectACity: _selectACity,
    _selectAnArea: _selectAnArea,
    _languageChangesSuccessfully: _languageChangesSuccessfully,
    _noOrdersFound: _noOrdersFound,
    _noFavoritesFound: _noFavoritesFound,
    _noTicketsFound: _noTicketsFound,
    _noRatingsFound: _noRatingsFound,
    _relatedServices: _relatedServices,
    _sold: _sold,
    _noFaqAdded: _noFaqAdded,
    _noAddonsFound: _noAddonsFound,
    _noStaffAdded: _noStaffAdded,
    _noOffersFound: _noOffersFound,
    _noServiceFound: _noServiceFound,
    _offerRejectedSuccessfully: _offerRejectedSuccessfully,
    _hello: _hello,
    _noServiceAddedYet: _noServiceAddedYet,
    _deleteJobConfirmation: "",
    _deleteJobDescription: "",
    _jobDeletedSuccessfully: "",
    _openingMap: "",
    _officialPlatformProvider: "",
   _refundPaymentMethod: "",
   _updateRefundInfo: "",
   _orderCancelledSuccessfully: "",
   _selectAPaymentMethod: "",
   _status: "",
   _requestRefund: "",
   _sendRequest: "",
   _refundRequestSentSuccessfully: "",
   _refunds: "",
   _infoUpdatedSuccessfully: "",
   _somethingWentWrong: "",
   _updatePaymentInfo: "",
   _update0: "",
   _noPaymentInfoFound: "",
   _refundAmount: "",
   _status0: "",
   _refundRequest: "",
   _refunded: "",
   _notSpecified: "",
  };
}
