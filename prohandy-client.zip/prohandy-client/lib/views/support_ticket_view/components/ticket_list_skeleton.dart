import 'package:flutter/material.dart';
import 'package:prohandy_client/helper/extension/context_extension.dart';
import 'package:prohandy_client/helper/extension/int_extension.dart';
import 'package:prohandy_client/helper/extension/widget_extension.dart';
import 'package:prohandy_client/utils/components/custom_squircle_widget.dart';
import 'package:prohandy_client/utils/components/text_skeleton.dart';

class TicketListSkeleton extends StatelessWidget {
  const TicketListSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(vertical: 24),
            itemBuilder: (context, index) {
              return SquircleContainer(
                  padding: const EdgeInsets.all(16),
                  radius: 10,
                  borderColor: context.color.primaryBorderColor,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Wrap(
                        spacing: 6,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          TextSkeleton(
                            height: 12,
                            width: 30,
                          ),
                        ],
                      ),
                      8.toHeight,
                      TextSkeleton(
                        height: 18,
                        width: context.width * .5,
                      ),
                      10.toHeight,
                      TextSkeleton(
                        height: 12,
                        width: context.width * .8,
                      ),
                      4.toHeight,
                      const Wrap(
                        spacing: 4,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          TextSkeleton(
                            height: 14,
                            width: 30,
                          ),
                          TextSkeleton(
                            height: 12,
                            width: 56,
                          )
                        ],
                      )
                    ],
                  ));
            },
            separatorBuilder: (context, index) => const SizedBox(height: 12),
            itemCount: 10)
        .shim;
  }
}
