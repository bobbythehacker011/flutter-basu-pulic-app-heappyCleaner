import 'package:flutter/material.dart';

class HiringPaymentSuccessSheet extends StatelessWidget {
  const HiringPaymentSuccessSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return const Material();
  }
}
