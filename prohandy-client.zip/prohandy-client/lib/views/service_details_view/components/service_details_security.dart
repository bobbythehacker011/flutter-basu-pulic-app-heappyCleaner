import 'package:flutter/material.dart';
import 'package:prohandy_client/helper/extension/context_extension.dart';
import 'package:prohandy_client/helper/extension/int_extension.dart';
import 'package:prohandy_client/helper/extension/string_extension.dart';
import 'package:prohandy_client/helper/local_keys.g.dart';
import 'package:prohandy_client/helper/svg_assets.dart';

class ServiceDetailsSecurity extends StatelessWidget {
  const ServiceDetailsSecurity({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      color: context.color.accentContrastColor,
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: context.color.mutedSuccessColor,
                child: SvgAssets.verified
                    .toSVGSized(24, color: context.color.primarySuccessColor),
              ),
              12.toWidth,
              Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        LocalKeys.safetyAndSecurity,
                        style: context.titleMedium?.bold,
                      ),
                      4.toHeight,
                      Text(
                        "All our handyman’s are verified to provide you sense of security",
                        style: context.bodySmall,
                      ),
                    ],
                  ))
            ],
          )
        ],
      ),
    );
  }
}
