import 'package:flutter/material.dart';

class RatingTileUser extends StatelessWidget {
  const RatingTileUser({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}