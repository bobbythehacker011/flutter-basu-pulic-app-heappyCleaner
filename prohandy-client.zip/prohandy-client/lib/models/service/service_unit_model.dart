class ServiceUnit {
  final dynamic id;
  final String title;

  ServiceUnit({
    required this.id,
    required this.title,
  });
}
