import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:prohandy_client/helper/app_urls.dart';
import 'package:prohandy_client/helper/constant_helper.dart';
import 'package:prohandy_client/helper/extension/string_extension.dart';
import 'package:prohandy_client/helper/local_keys.g.dart';
import 'package:prohandy_client/models/address_models/address_model.dart';

import '../../data/network/network_api_services.dart';

class AddressListService with ChangeNotifier {
  AddressListModel? _addressListModel;
  AddressListModel get addressListModel =>
      _addressListModel ?? AddressListModel(allLocations: []);

  String token = "";
  var nextPage;

  bool nextPageLoading = false;

  bool nexLoadingFailed = false;
  bool isLoading = false;

  bool get shouldAutoFetch => _addressListModel == null || token.isInvalid;

  fetchAddressList({bool refresh = false}) async {
    token = getToken;
    if (!refresh) {
      isLoading = true;
      notifyListeners();
    }
    var url = AppUrls.addressListUrl;
    debugPrint(url.toString());

    final responseData = await NetworkApiServices()
        .getApi(url, LocalKeys.jobs, headers: acceptJsonAuthHeader);

    try {
      if (responseData != null) {
        final tempData = AddressListModel.fromJson(responseData);
        _addressListModel = tempData;
        nextPage = tempData.pagination?.nextPageUrl;
        isLoading = false;
        notifyListeners();
        return true;
      } else {
        _addressListModel ??= AddressListModel(allLocations: []);
      }
    } catch (e) {
      debugPrint(e.toString());
      log(e.toString());
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  fetchNextPage() async {
    token = getToken;
    if (nextPageLoading) return;
    nextPageLoading = true;
    notifyListeners();
    final responseData = await NetworkApiServices()
        .getApi(nextPage, LocalKeys.jobs, headers: commonAuthHeader);

    if (responseData != null) {
      final tempData = AddressListModel.fromJson(responseData);
      for (var element in tempData.allLocations) {
        _addressListModel?.allLocations.add(element);
      }
      nextPage = tempData.pagination?.nextPageUrl;
    } else {
      nexLoadingFailed = true;
      Future.delayed(const Duration(seconds: 1)).then((value) {
        nexLoadingFailed = false;
        notifyListeners();
      });
    }
    nextPageLoading = false;
    notifyListeners();
  }

  void removeAddress(id) {
    _addressListModel?.allLocations
        .removeWhere((address) => address.id.toString() == id.toString());
    notifyListeners();
  }

  reset() {
    _addressListModel = null;
  }
}
