import 'package:timeago/timeago.dart' as timeago;

// Complete map of all supported timeago languages
Map<String, timeago.LookupMessages> timeAgoSupportedLangs = {
  'ar': timeago.ArMessages(), // Arabic
  'az': timeago.AzMessages(), // Azerbaijani
  'be': timeago.BeMessages(), // Bulgarian
  'bn': timeago.BnMessages(), // Bengali
  'bs': timeago.BsMessages(), // Bosnian
  'ca': timeago.CaMessages(), // Catalan
  'cs': timeago.CsMessages(), // Czech
  'da': timeago.DaMessages(), // Danish
  'de': timeago.DeMessages(), // German
  'dv': timeago.DvMessages(), // Divehi
  'en': timeago.EnMessages(), // English
  'es': timeago.EsMessages(), // Spanish
  'et': timeago.EtMessages(), // Estonian
  'fa': timeago.FaMessages(), // Persian/Farsi
  'fi': timeago.FiMessages(), // Finnish
  'fr': timeago.FrMessages(), // French
  'he': timeago.HeMessages(), // Hebrew
  'hi': timeago.HiMessages(), // Hindi
  'hr': timeago.HrMessages(), // Croatian
  'hu': timeago.HuMessages(), // Hungarian
  'id': timeago.IdMessages(), // Indonesian
  'it': timeago.ItMessages(), // Italian
  'ja': timeago.JaMessages(), // Japanese
  'km': timeago.KmMessages(), // Khmer
  'ko': timeago.KoMessages(), // Korean
  'ku': timeago.KuMessages(), // Kurdish
  'lv': timeago.LvMessages(), // Latvian
  'mn': timeago.MnMessages(), // Mongolian
  'my': timeago.MyMessages(), // Myanmar/Burmese
  'nb': timeago.NbNoMessages(), // Norwegian Bokmål
  'nl': timeago.NlMessages(), // Dutch
  'nn': timeago.NnNoMessages(), // Norwegian Nynorsk
  'pl': timeago.PlMessages(), // Polish
  'pt': timeago.PtBrMessages(), // Portuguese (Brazil)
  'ro': timeago.RoMessages(), // Romanian
  'ru': timeago.RuMessages(), // Russian
  'rw': timeago.RwMessages(), // Kinyarwanda
  'sr': timeago.SrMessages(), // Serbian
  'sv': timeago.SvMessages(), // Swedish
  'ta': timeago.TaMessages(), // Tamil
  'th': timeago.ThMessages(), // Thai
  'tk': timeago.TkMessages(), // Turkmen
  'tr': timeago.TrMessages(), // Turkish
  'uk': timeago.UkMessages(), // Ukrainian
  'ur': timeago.UrMessages(), // Urdu
  'vi': timeago.ViMessages(), // Vietnamese
  'zh': timeago.ZhMessages(), // Chinese (Simplified)
  'zh_CN': timeago.ZhCnMessages(), // Chinese (Simplified, China)
  'zh_TW': timeago.ZhMessages(), // Chinese (Traditional, Taiwan)
};
