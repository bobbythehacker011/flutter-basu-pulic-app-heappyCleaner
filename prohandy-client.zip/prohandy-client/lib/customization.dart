String siteLink = 'https://prohandy.xgenious.com';

String appLabel = 'Prohandy';
String storeLabel = "Prohandy";
String appVersion = '1.0';
String mapApiKey = '';

String socialSignInKey =
    '\$2y\$10\$GlEhJtlTAqv2rvQd2llgPeGGV8RT2Yap844OSazHfHlbU.0bvVTPm';
String paymentUpdateKey =
    'e2b8c14a6f8b6d4f9c5f6e8b0d4c1a6e0b9c7f5a2e6b4d8c7a1e3f4d6b8c5f9';

String get baseEndPoint => "$siteLink/api/v1";
